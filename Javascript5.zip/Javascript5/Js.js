let lista = document.getElementById("sampleList");

const ccList=["only-fifth","after-fifth","first-ten","every-third","first-then-every-third","odd","efifth-from-end"]

for(let indexU1 =0; indexU1<7; indexU1++){
    let ul = document.createElement("ul")
    lista.appendChild(ul);
    ul.classList.add(ccList[indexU1],"m-box");

    for (let indexLi=0; indexLi <15; indexLi++){
        let li=document.createElement("li");
        ul.appendChild(li);
        li.setAttribute("style","margin-left:3px");
        li.innerHTML=indexLi+1
    }
}
console.log(lista);